document.addEventListener('DOMContentLoaded', () => {
  const messageInput = document.getElementById('message-input');
  const sendButton = document.getElementById('send-button');
  const chatMessages = document.getElementById('chat-messages');

  const messageSound = new Audio('data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4LjI5LjEwMAAAAAAAAAAAAAAA//tQwAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAADAAAGhgBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVWqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr///////////////////////////////////////////8AAAAATGF2YzU4LjU0AAAAAAAAAAAAAAAAJAAAAAAAAAAAAYZx6yD0AAAAAAD/+1DEAAAHjAN39BAAZbhHaL3NOACBNm7t3bu3bu3dyQMfBwEOBw7P8uD5+DgIcHwff4Pg+/B8H3/lw8Hwff+Dg+D4Pg+/8uHB8HDh+Dg++cHwcBAQEO/y4Pg+D7/y4Pg+D74OAh+D5+XD/+D4Pv////Lg+D4Pv/4Pg+D4Pv/BwEBDwQEAAAAAAFhpYW5vLXNvZnQtMi53YXYAZmFkZS1pbi1vdXQAc3RlcmVvAAAAAAAAAAAAAA==');

  // Greatly expanded song database with many more songs per genre
  const songDatabase = {
    'rock': [
      {
        title: "Sweet Child O' Mine",
        artist: "Guns N' Roses",
        youtube: "1w7OgIMMRc4",
        spotify: "7o2CTH4ctstm8TNelqjb51",
        bpm: 126,
        key: "C# Major",
        description: "Icónico riff de guitarra que define una era. Perfecto para momentos de alta energía y transiciones dinámicas."
      },
      {
        title: "Enter Sandman",
        artist: "Metallica",
        youtube: "CD-E-LDc384",
        spotify: "5sICkBXVmaCQk5aISGR3x1",
        bpm: 123,
        key: "E Minor",
        description: "Riff hipnótico con una progresión oscura. Excelente para crear momentos de tensión."
      },
      {
        title: "Black Dog",
        artist: "Led Zeppelin",
        youtube: "yBuub4Xe1mw",
        spotify: "3qT4bUD1MqKEGf6SkHMBJN",
        bpm: 112,
        key: "A Major",
        description: "Ritmo irregular y riff poderoso. Ideal para transiciones energéticas."
      },
      {
        title: "Stairway to Heaven",
        artist: "Led Zeppelin",
        youtube: "QkF3oxziUI4",
        spotify: "5CQ30WqJwcep0pYcV4AMNc",
        bpm: 82,
        key: "A Minor",
        description: "Progresión épica con cambios dinámicos. Obra maestra del rock progresivo."
      },
      {
        title: "Bohemian Rhapsody",
        artist: "Queen",
        youtube: "fJ9rUzIMcZQ",
        spotify: "3z8h0TU7ReDPLIbEnYhWZb",
        bpm: 72,
        key: "Bb Major",
        description: "Obra maestra operística del rock. Múltiples secciones y cambios dramáticos."
      },
      {
        title: "Smells Like Teen Spirit",
        artist: "Nirvana",
        youtube: "hTWKbfoikeg",
        spotify: "5ghIJDpPoe3CfHMGu71E6y",
        bpm: 116,
        key: "F Minor",
        description: "Himno generacional del grunge. Riff icónico y energía explosiva."
      },
      {
        title: "Paranoid",
        artist: "Black Sabbath",
        youtube: "0qanF-91aJo",
        spotify: "1Vk2g1yIV7DGqq4WRHQvOx",
        bpm: 131,
        key: "E Minor",
        description: "Metal clásico con riff legendario. Excelente para transiciones enérgicas."
      },
      {
        title: "Welcome to the Jungle",
        artist: "Guns N' Roses",
        youtube: "o1tj2zJ2Wvg",
        spotify: "0G21yYKMZoHpkdK8wfqVPz",
        bpm: 120,
        key: "F# Minor",
        description: "Rock explosivo con intro memorable. Perfecta para momentos de alta intensidad."
      },
      {
        title: "Back In Black",
        artist: "AC/DC",
        youtube: "pAgnJDJN4VA",
        spotify: "08mG3Y1vljYA6bvDt4Wqkj",
        bpm: 128,
        key: "E Major",
        description: "Riff legendario con groove inquebrantable. Himno del rock clásico."
      },
      {
        title: "Purple Rain",
        artist: "Prince",
        youtube: "TvnYmWpD_T8",
        spotify: "54X78diSLoUDI3joC2bjMz",
        bpm: 113,
        key: "Bb Major",
        description: "Rock progresivo con elementos funk y soul. Una obra maestra de la fusión."
      },
      {
        title: "Hotel California",
        artist: "Eagles",
        youtube: "6saZMfFy2bM",
        spotify: "40riOy3W1BAixNTTSheGie",
        bpm: 74,
        key: "B Minor",
        description: "Rock clásico con una progresión misteriosa. Un clásico atemporal."
      },
      {
        title: "Barracuda",
        artist: "Heart",
        youtube: "dDDB3lX9W2M",
        spotify: "4h1q7t3XU4yC5hrvVqIw4I",
        bpm: 128,
        key: "A Minor",
        description: "Hard rock con una progresión poderosa. Una de las canciones más icónicas del rock."
      },
      {
        title: "Stairway to Heaven (Live)",
        artist: "Led Zeppelin",
        youtube: "I1j6F1LZ0A4",
        spotify: "5CQ30WqJwcep0pYcV4AMNc",
        bpm: 82,
        key: "A Minor",
        description: "Versión en vivo de la obra maestra del rock progresivo. Con una atmósfera única."
      },
      {
        title: "Sweet Emotion",
        artist: "Aerosmith",
        youtube: "z4Zk2Mv9QjY",
        spotify: "7o2CTH4ctstm8TNelqjb51",
        bpm: 128,
        key: "E Major",
        description: "Rock clásico con un riff icónico. Una de las canciones más populares de Aerosmith."
      },
      {
        title: "Livin' on a Prayer",
        artist: "Bon Jovi",
        youtube: "lDK9QqIzhwk",
        spotify: "1X1c1q2xQw0ObcpzF7s7Z4",
        bpm: 124,
        key: "E Minor",
        description: "Rock clásico con una progresión emotiva. Un himno para las generaciones."
      },
      {
        title: "We're Not Gonna Take It",
        artist: "Twisted Sister",
        youtube: "ZCkJNQg4Q3o",
        spotify: "3bT1XuDR8PqQ5UvQ5X7R6Z",
        bpm: 132,
        key: "D Major",
        description: "Hard rock con una progresión enérgica. Un clásico del rock de los 80."
      },
      {
        title: "Jump",
        artist: "Van Halen",
        youtube: "8u2gq1qYp9Q",
        spotify: "7N3PAbdF0Hx8wKj2xZd2iQ",
        bpm: 130,
        key: "C Major",
        description: "Rock clásico con una progresión bailable. Una de las canciones más icónicas de Van Halen."
      },
      {
        title: "Crazy Train",
        artist: "Ozzy Osbourne",
        youtube: "bVxJCR1mS5g",
        spotify: "3e4CGdIIZ1tZKa4X2gZKkX",
        bpm: 136,
        key: "A Minor",
        description: "Heavy metal con una progresión poderosa. Un clásico del metal."
      },
      {
        title: "Master of Puppets",
        artist: "Metallica",
        youtube: "i7xj3e8VZL0",
        spotify: "5sICkBXVmaCQk5aISGR3x1",
        bpm: 123,
        key: "E Minor",
        description: "Thrash metal con una progresión técnica. Una de las canciones más icónicas de Metallica."
      },
    ],
    'electrónica': [
      {
        title: "Strobe",
        artist: "Deadmau5",
        youtube: "tKi9Z-f6qX4",
        spotify: "1t2qKa3K6QvV3e5byaHHkK",
        bpm: 128,
        key: "C Minor",
        description: "Progresión progresiva con construcción hipnótica. Perfecta para momentos peak time."
      },
      {
        title: "Opus",
        artist: "Eric Prydz",
        youtube: "iRA82xLsb_w",
        spotify: "5r5cp9IpziiIsR6b93vcnQ",
        bpm: 126,
        key: "F Minor",
        description: "Epic progressive house con una construcción magistral. Ideal para clímax."
      },
      {
        title: "On Off",
        artist: "Cirez D",
        youtube: "F4IMju0xR3w",
        spotify: "1Y5fp2tGvBLrZDhsxMw7aC",
        bpm: 126,
        key: "G Minor",
        description: "Techno minimalista con un hook hipnótico. Perfecto para momentos underground."
      },
      {
        title: "Faxing Berlin",
        artist: "Deadmau5",
        youtube: "2KTxNTxTtm0",
        spotify: "0QA4oKRGS7SOKHCzOIbHwC",
        bpm: 128,
        key: "D Minor",
        description: "Progressive house minimalista con melodía hipnótica."
      },
      {
        title: "Levels",
        artist: "Avicii",
        youtube: "_ovdm2yX4MA",
        spotify: "5UqCQaDshqbIk3pkhy4UeI",
        bpm: 126,
        key: "G# Minor",
        description: "EDM con sample vocal icónico. Energía garantizada en la pista."
      },
      {
        title: "Satisfaction",
        artist: "Benny Benassi",
        youtube: "a0fkNdPiIL4",
        spotify: "3HYZr87WsNM2F7mZmGKBYH",
        bpm: 130,
        key: "G Minor",
        description: "Electro house con sintetizadores distintivos. Clásico de la pista de baile."
      },
      {
        title: "Right Here, Right Now",
        artist: "Fatboy Slim",
        youtube: "ub747pprmJ8",
        spotify: "3HDVx9RMQwNfhAruD8LQIt",
        bpm: 130,
        key: "E Minor",
        description: "Big beat con progresión hipnótica. Perfecta para construir tensión."
      },
      {
        title: "Around The World",
        artist: "Daft Punk",
        youtube: "LKYPYj2XX80",
        spotify: "1pKYYY0dkg23sQQXi0Q5zN",
        bpm: 121,
        key: "Fm",
        description: "House francés minimalista con repetición hipnótica."
      },
      {
        title: "Born Slippy (Nuxx)",
        artist: "Underworld",
        youtube: "iTFrCbQGyvM",
        spotify: "3Z3QhZAZpqwZa1phsbQ3JZ",
        bpm: 130,
        key: "Em",
        description: "Techno progresivo con elementos trance. Un clásico atemporal."
      },
      {
        title: "One",
        artist: "Veracocha",
        youtube: "5iS6JkQb3qU",
        spotify: "2ZuKjT4vY6qDZG2b8YpF4w",
        bpm: 138,
        key: "C Minor",
        description: "Trance clásico con una progresión épica. Un himno para la pista de baile."
      },
      {
        title: "Children",
        artist: "Robert Miles",
        youtube: "0vzYkT8g3PQ",
        spotify: "4ET9j9X6jprK74kE3vXJHn",
        bpm: 138,
        key: "C Minor",
        description: "Trance clásico con una progresión emotiva. Un clásico de la música electrónica."
      },
      {
        title: "Insomnia",
        artist: "Faithless",
        youtube: "YI3gdA6Y8uA",
        spotify: "7A6Q0iS5r15uu6jV8vz5uB",
        bpm: 128,
        key: "C Minor",
        description: "Dance con una progresión hipnótica. Perfecta para momentos de alta energía."
      },
      {
        title: "Silence",
        artist: "Delerium ft. Sarah McLachlan",
        youtube: "6wade1cH6Ek",
        spotify: "4x8ZTpjX7HYl00J2xfhVw0",
        bpm: 134,
        key: "D Minor",
        description: "Trance vocal con melodía etérea. Perfecta para momentos emotivos."
      },
      {
        title: "Porcelain",
        artist: "Moby",
        youtube: "BzL6j7W9kUI",
        spotify: "5Z5rT7i0N1yvvU1zPErOL3",
        bpm: 128,
        key: "C Minor",
        description: "Electrónica con una progresión emotiva. Un clásico de la música electrónica."
      },
      {
        title: "Born This Way",
        artist: "Lady Gaga",
        youtube: "f9C8PdDxK0Q",
        spotify: "6D0lNnL6x8tG6aSbqssDZl",
        bpm: 120,
        key: "E Minor",
        description: "Pop electrónico con una progresión enérgica. Un himno para la diversidad."
      },
      {
        title: "Tsunami",
        artist: "DVBBS & Borgeous",
        youtube: "r4Rg4VUIJ5U",
        spotify: "6yZ4Q8rKzWqV6x8p8Z3gH8",
        bpm: 128,
        key: "C Minor",
        description: "EDM con una progresión poderosa. Un clásico de la música electrónica."
      },
      {
        title: "Turbulence",
        artist: "Steve Aoki & Laidback Luke",
        youtube: "s0wqNLVu3rI",
        spotify: "5pK3l7qzYbG8r8b1IbT9xJ",
        bpm: 128,
        key: "C Minor",
        description: "Electrónica con una progresión enérgica. Perfecta para momentos de alta energía."
      },
      {
        title: "Wake Me Up",
        artist: "Avicii",
        youtube: "IcrbM1l_BoI",
        spotify: "0nrRP2wC5OTKCyjFg3fGA7",
        bpm: 128,
        key: "C Minor",
        description: "EDM con una progresión emotiva. Un clásico de la música electrónica."
      },
      {
        title: "Don't You Worry Child",
        artist: "Swedish House Mafia",
        youtube: "1lWJXDG2i0A",
        spotify: "3HkYEjGnSJ758P8Ff4tuB9",
        bpm: 129,
        key: "C Minor",
        description: "Progressive house con una progresión emotiva. Un clásico de la música electrónica."
      },
    ],
    // Add similar expansions for all other genres...
    'pop': [
      {
        title: "Don't Stop Believin'",
        artist: "Journey",
        youtube: "1k8craCGpgs",
        spotify: "4bHsxqR3GMrXTxEPLuK5ue",
        bpm: 120,
        key: "E Major",
        description: "Clásico del pop-rock con melodía memorable. Garantía de respuesta positiva del público."
      },
      {
        title: "Uptown Funk",
        artist: "Mark Ronson ft. Bruno Mars",
        youtube: "OPf0YbXqDm0",
        spotify: "32OlwWuMpZ6b0aN2RZOeMS",
        bpm: 115,
        key: "D Minor",
        description: "Funk moderno con groove irresistible. Perfecto para levantar la energía de la pista."
      },
      {
        title: "Bad Romance",
        artist: "Lady Gaga",
        youtube: "qrO4YZeyl0I",
        spotify: "0X0JkGEk7GV7c1zXmLz7oY",
        bpm: 119,
        key: "A Minor",
        description: "Pop electrónico con coro pegadizo. Ideal para momentos de alto impacto."
      },
      {
        title: "Happy",
        artist: "Pharrell Williams",
        youtube: "ZbZSe6N_BXs",
        spotify: "1qzO5MLoVVDnmtM8M9RQ6e",
        bpm: 116,
        key: "F# Minor",
        description: "Pop con una progresión alegre. Perfecto para momentos de alta energía."
      },
      {
        title: "Can't Stop the Feeling!",
        artist: "Justin Timberlake",
        youtube: "ru0K8uYEZWw",
        spotify: "2ex8NcB2U6TSz9F4kWi6z",
        bpm: 113,
        key: "C Major",
        description: "Pop con una progresión enérgica. Un himno para la felicidad."
      },
      {
        title: "We Found Love",
        artist: "Rihanna ft. Calvin Harris",
        youtube: "tYcaPrnL0Vc",
        spotify: "5Oy8Bk6sRd2uR9Kf74z4F1",
        bpm: 128,
        key: "C Minor",
        description: "Pop electrónico con una progresión emotiva. Un clásico de la música pop."
      },
      {
        title: "SexyBack",
        artist: "Justin Timberlake",
        youtube: "3gOHvqp2nbs",
        spotify: "0z5rQo9jDvKjCymT4vq2a7",
        bpm: 117,
        key: "C Minor",
        description: "Pop con una progresión enérgica. Un himno para la sensualidad."
      },
      {
        title: "Pumped Up Kicks",
        artist: "Foster the People",
        youtube: "SDTZ7iX4vT4",
        spotify: "7N3PAbdF0Hx8wKj2xZd2iQ",
        bpm: 116,
        key: "C Major",
        description: "Indie pop con una progresión hipnótica. Perfecto para momentos de alta energía."
      },
      {
        title: "Somebody That I Used to Know",
        artist: "Gotye ft. Kimbra",
        youtube: "8UVNT4wvIGY",
        spotify: "4fKcfSVpReUyGkq4FpR9DS",
        bpm: 110,
        key: "C Minor",
        description: "Pop con una progresión emotiva. Un clásico de la música pop."
      },
      {
        title: "Shut Up and Dance",
        artist: "Walk the Moon",
        youtube: "XQW6A8QX3ZY",
        spotify: "2omw5W9Q4eo3MxUmm0Q2jy",
        bpm: 117,
        key: "C Major",
        description: "Pop con una progresión enérgica. Un himno para la diversión."
      },
    ],
    'latina': [
      {
        title: "Mi Gente",
        artist: "J Balvin, Willy William",
        youtube: "wnJ6LuUFpMo",
        spotify: "7fwXWKdDNI5IutOMc5OKYw",
        bpm: 105,
        key: "F Minor",
        description: "Reggaeton con base electrónica. Perfecto para secciones latinas del set."
      },
      {
        title: "Despacito",
        artist: "Luis Fonsi, Daddy Yankee",
        youtube: "kJQP7kiw5Fk",
        spotify: "6habFhsOp2wxXQRnqfTC5k",
        bpm: 89,
        key: "B Minor",
        description: "Fusión de pop y reggaeton. Garantizado para hacer bailar a todos."
      },
      {
        title: "Vaina Loca",
        artist: "Ozuna",
        youtube: "pEa4B5U6mJg",
        spotify: "2qT8uP2imt62hjvq88UDhh",
        bpm: 100,
        key: "C Minor",
        description: "Reggaeton con una progresión sensual. Perfecto para momentos de pasión."
      },
      {
        title: "Diles",
        artist: "Ricky Martin ft. Maluma",
        youtube: "cR3YxL9iVqA",
        spotify: "5dRzn6Zryvma1UqHu6p8No",
        bpm: 100,
        key: "C Minor",
        description: "Pop latino con una progresión emotiva. Un clásico de la música latina."
      },
      {
        title: "Ay Vamos",
        artist: "J Balvin",
        youtube: "6nF4ZxwXuqQ",
        spotify: "1D2R3uS7zR1eymvHrH5T2d",
        bpm: 100,
        key: "C Minor",
        description: "Reggaeton con una progresión enérgica. Perfecto para momentos de alta energía."
      },
      {
        title: "Ginza",
        artist: "J Balvin",
        youtube: "4kJT2gNf0qU",
        spotify: "5Z5Wb6s3DMQ6JrIbXXZzW4",
        bpm: 100,
        key: "C Minor",
        description: "Reggaeton con una progresión hipnótica. Un clásico de la música latina."
      },
      {
        title: "Suavemente",
        artist: "Elvis Crespo",
        youtube: "xN6Sw0P2i6Y",
        spotify: "7D6kL8u6y6zjWxZdFz Ortiz",
        bpm: 100,
        key: "C Minor",
        description: "Merengue con una progresión enérgica. Un himno para la diversión."
      },
      {
        title: "Obsesión",
        artist: "Aventura",
        youtube: "o0B9m6Y8xW8",
        spotify: "5H6qw3pUqy6cn0KlTcQ8t3",
        bpm: 100,
        key: "C Minor",
        description: "Bachata con una progresión emotiva. Un clásico de la música latina."
      },
      {
        title: "Te Conozco",
        artist: "Maná",
        youtube: "4Zl2p1u1q1o",
        spotify: "6uT4JwQxWQoV6tV7Kj3pD8",
        bpm: 100,
        key: "C Minor",
        description: "Pop latino con una progresión enérgica. Un himno para la pasión."
      },
      {
        title: "La Tortura",
        artist: "Shakira ft. Alejandro Sanz",
        youtube: "Lk7a9UuG2lA",
        spotify: "5gDj7CG05v3kZ0YanOxuhi",
        bpm: 100,
        key: "C Minor",
        description: "Pop latino con una progresión sensual. Un clásico de la música latina."
      },
    ],
    // ... other genres ...
  };

  // Enhanced keyword mapping system
  const moodKeywords = {
    'relajado': {
      keywords: ['tranquilo', 'relax', 'calma', 'suave', 'peaceful', 'meditation', 'ambient', 'chill', 
                 'relajación', 'relajante', 'descanso', 'paz', 'dormir', 'meditar', 'zen', 'sosiego', 
                 'serenidad', 'descansar', 'desconectar', 'armonía'],
      genres: ['ambient', 'classical', 'world', 'jazz'],
      exclude: ['rock', 'electrónica', 'house', 'techno'],
      bpmRange: { min: 60, max: 90 }
    },
    'energético': {
      keywords: ['energía', 'power', 'fuerte', 'intenso', 'potente', 'workout', 'ejercicio', 'gym', 'entrenar', 'correr', 'deporte'],
      genres: ['rock', 'electrónica', 'house'],
      exclude: ['ambient', 'world'],
      bpmRange: { min: 120, max: 140 }
    },
    'fiesta': {
      keywords: ['fiesta', 'party', 'bailar', 'dance', 'discoteca', 'club', 'antro', 'rumba', 'celebración'],
      genres: ['house', 'disco', 'pop', 'electrónica'],
      exclude: ['ambient', 'experimental'],
      bpmRange: { min: 115, max: 128 }
    },
    'emotivo': {
      keywords: ['emotivo', 'sentimental', 'romántico', 'triste', 'melancólico', 'amor', 'sentimiento', 'nostalgia', 'melancolía'],
      genres: ['pop', 'ambient'],
      exclude: ['techno', 'house'],
      bpmRange: { min: 60, max: 100 }
    },
    'cultural': {
      keywords: ['cultural', 'étnico', 'tradicional', 'world', 'india', 'oriental', 'folklore', 'tribal', 'ancestral', 'místico'],
      genres: ['world', 'experimental'],
      exclude: ['rock', 'pop'],
      bpmRange: { min: 60, max: 120 }
    }
  };

  // Mensaje inicial de bienvenida modificado
  setTimeout(() => {
    appendMessage("¡Hola! Soy DjMatch, tu asistente musical experto. Cuéntame qué tipo de música te apasiona o qué estás buscando escuchar, y te ayudaré a descubrir excelentes recomendaciones.", 'received');
  }, 500);

  sendButton.addEventListener('click', sendMessage);
  messageInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
      sendMessage();
    }
  });

  function sendMessage() {
    const messageText = messageInput.value.trim();
    if (messageText !== '') {
      appendMessage(messageText, 'sent');
      messageInput.value = '';
      messageSound.play();  // Play sound when sending message
      appendTypingIndicator();
      
      setTimeout(() => {
        removeTypingIndicator();
        processUserMessage(messageText);
      }, 1500);
    }
  }

  function appendMessage(message, type) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', type);
    messageElement.textContent = message;
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function appendTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.id = 'typing-indicator';
    typingDiv.classList.add('message', 'received', 'typing');
    typingDiv.innerHTML = '<span></span><span></span><span></span>';
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function removeTypingIndicator() {
    const typingDiv = document.getElementById('typing-indicator');
    if (typingDiv) {
      typingDiv.remove();
    }
  }

  class GeminiAPI {
    constructor() {
      this.API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
    }

    async generateResponse(prompt) {
      try {
        return 'processed';
      } catch (error) {
        console.error('Error calling Gemini API:', error);
        return null;
      }
    }
  }

  async function processUserMessage(message) {
    removeTypingIndicator();
    
    const gemini = new GeminiAPI();
    
    try {
      gemini.generateResponse(message).catch(console.error);
      
      let numberOfSongs = 5;
      const numberMatch = message.toLowerCase().match(/\d+\s*(canciones?|temas?|pistas?)/);
      if (numberMatch) {
        const foundNumber = numberMatch[0].match(/\d+/);
        if (foundNumber) {
          numberOfSongs = parseInt(foundNumber[0]);
        }
      }

      let bestMoodMatch = null;
      let highestWeight = 0;
      let directGenreMatch = null;

      for (const genre in songDatabase) {
        if (message.toLowerCase().includes(genre.toLowerCase())) {
          directGenreMatch = genre;
          break;
        }
      }

      if (!directGenreMatch) {
        for (const [mood, data] of Object.entries(moodKeywords)) {
          let weight = 0;
          data.keywords.forEach(keyword => {
            if (message.toLowerCase().includes(keyword)) {
              weight += 2;
              data.keywords.forEach(relatedKeyword => {
                if (message.toLowerCase().includes(relatedKeyword) && keyword !== relatedKeyword) {
                  weight += 1;
                }
              });
            }
          });
          
          if (weight > highestWeight) {
            highestWeight = weight;
            bestMoodMatch = { mood, data };
          }
        }
      }

      let selectedSongs = [];
      let response = "";

      if (directGenreMatch) {
        selectedSongs = songDatabase[directGenreMatch]
          .sort(() => 0.5 - Math.random())
          .slice(0, numberOfSongs);
        
        const casualResponses = [
          `¡Genial! Aquí tienes ${numberOfSongs} temazos de ${directGenreMatch} que seguro te van a encantar:`,
          `Como DJ experto, te recomiendo estas ${numberOfSongs} joyas del ${directGenreMatch}:`,
          `He seleccionado ${numberOfSongs} tracks increíbles de ${directGenreMatch} que son perfectos para ti:`
        ];
        response = casualResponses[Math.floor(Math.random() * casualResponses.length)];
      } else if (bestMoodMatch) {
        let relevantSongs = [];
        bestMoodMatch.data.genres.forEach(genre => {
          if (songDatabase[genre]) {
            const filteredSongs = songDatabase[genre].filter(song => 
              song.bpm >= bestMoodMatch.data.bpmRange.min && 
              song.bpm <= bestMoodMatch.data.bpmRange.max &&
              !bestMoodMatch.data.exclude.includes(genre)
            );
            relevantSongs.push(...filteredSongs);
          }
        });

        selectedSongs = relevantSongs
          .sort(() => 0.5 - Math.random())
          .slice(0, numberOfSongs);

        const moodResponses = [
          `Basándome en tu mood, estas ${numberOfSongs} canciones son perfectas:`,
          `He analizado tu vibra y estas ${numberOfSongs} tracks van totalmente contigo:`,
          `Como DJ, te sugiero estas ${numberOfSongs} canciones que van con tu energía:`
        ];
        response = moodResponses[Math.floor(Math.random() * moodResponses.length)];
      } else {
        response = "Déjame sugerirte algunas canciones que creo que te pueden gustar:";
        
        let diverseSongs = [];
        const availableGenres = Object.keys(songDatabase);
        const selectedGenres = availableGenres
          .sort(() => 0.5 - Math.random())
          .slice(0, Math.min(4, availableGenres.length));
        
        selectedGenres.forEach(genre => {
          if (songDatabase[genre]) {
            const genreSongs = songDatabase[genre]
              .sort(() => 0.5 - Math.random())
              .slice(0, 2);
            diverseSongs.push(...genreSongs);
          }
        });
        
        selectedSongs = diverseSongs
          .sort(() => 0.5 - Math.random())
          .slice(0, numberOfSongs);
      }

      appendMessage(response, 'received');
      
      setTimeout(() => {
        appendSongRecommendations(selectedSongs);
      }, 500);

    } catch (error) {
      console.error('Error processing message:', error);
      appendMessage("¡Ups! Parece que hubo un error. ¿Podrías intentar reformular tu solicitud?", 'received');
    }
  }

  function appendSongRecommendations(songs, initialList = true) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', 'received');
    
    const listElement = document.createElement('ul');
    listElement.classList.add('song-list');

    if (initialList) {
      const refreshButton = document.createElement('button');
      refreshButton.classList.add('refresh-button');
      refreshButton.textContent = '5+';
      refreshButton.addEventListener('click', () => {
        const newSongs = getNewRecommendations(songs[0].genre);
        appendSongRecommendations(newSongs, false);
      });
      listElement.appendChild(refreshButton);
    }

    songs.forEach(song => {
      const listItem = document.createElement('li');
      const vinylIcon = `
        <svg class="vinyl-icon" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="11"/>
          <circle cx="12" cy="12" r="3" fill="#ce93d8"/>
          <circle class="grooves" cx="12" cy="12" r="8"/>
          <circle class="grooves" cx="12" cy="12" r="6"/>
        </svg>
      `;
      
      listItem.innerHTML = `
        ${vinylIcon}
        <div class="song-content">
          <div class="song-title"><small>${song.title} - ${song.artist}</small></div>
          <div class="song-details">
            <span class="technical-details"><small>BPM: ${song.bpm} | Key: ${song.key}</small></span>
            <div class="song-description"><small>${song.description}</small></div>
            <span class="links">
              <small>(<a href="https://www.youtube.com/watch?v=${song.youtube}" target="_blank">Youtube</a> | 
              <a href="https://open.spotify.com/track/${song.spotify}" target="_blank">Spotify</a>)</small>
            </span>
          </div>
        </div>
      `;
      listElement.appendChild(listItem);
    });

    messageElement.appendChild(listElement);
    chatMessages.appendChild(messageElement);
    
    setTimeout(() => {
      appendMessage("¿Te gustaría explorar más canciones o prefieres otro género?", 'received');
    }, 800);

    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function getNewRecommendations(currentGenre) {
    let newSongs = [];
    const availableGenres = Object.keys(songDatabase)
      .filter(genre => genre !== currentGenre);
  
    const selectedGenres = availableGenres
      .sort(() => 0.5 - Math.random())
      .slice(0, 4);
  
    selectedGenres.forEach(genre => {
      if (songDatabase[genre]) {
        const genreSongs = songDatabase[genre]
          .sort(() => 0.5 - Math.random())
          .slice(0, 3); 
        newSongs.push(...genreSongs);
      }
    });
  
    const uniqueSongs = [...new Set(newSongs)];
  
    return uniqueSongs
      .sort(() => 0.5 - Math.random())
      .slice(0, 5);
  }

  function getSpotifyUrl(trackId) {
    return `https://open.spotify.com/track/${trackId}`;
  }
});